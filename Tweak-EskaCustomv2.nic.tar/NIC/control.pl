my $default_kill = "SpringBoard";
my $default_message = "Hack sudah Aktif!!";


NIC->variable("KILL_RULE") = "";
NIC->variable("MESSAGE") = "";

my $kill_apps = NIC->prompt("KILL_APPS", "List of applications to terminate upon installation (space-separated, '-' for none)", {default => $default_kill});
if($kill_apps ne "-") {
	NIC->variable("KILL_RULE") = "INSTALL_TARGET_PROCESSES = ".$kill_apps."\n\n";
}
my $add_message = NIC->prompt("ADD_MESSAGE", "Masukkan Pesan untuk PopUP : (Jika Kosong Maka Default)", {default => $default_message});
if($add_message ne "-") {
    NIC->variable("ADD_MESSAGE") = "".$add_message."";
}
